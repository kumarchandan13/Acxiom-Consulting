namespace AcxiomCRM.DTOs;
public record CustomerDto(int CustomerId,string CustomerCode,string CustomerName,string Email,string Phone,string? CompanyName,string? City,string Status,DateTime CreatedDate);
public record CustomerCreateDto(string CustomerName,string Email,string Phone,string? CompanyName,string? Address,string? City,string? State,string Status);
