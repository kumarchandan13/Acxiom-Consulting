using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers;
[Authorize]
public class LeadsController : Controller
{
    private readonly ApplicationDbContext _db; private readonly IAuditService _audit;
    public LeadsController(ApplicationDbContext db, IAuditService audit) { _db=db; _audit=audit; }
    public async Task<IActionResult> Index(string? search, string? status)
    {
        var q=_db.Leads.AsQueryable();
        if(User.IsInRole("SalesExecutive")) q=q.Where(x=>x.AssignedTo==User.Identity!.Name);
        if(!string.IsNullOrWhiteSpace(search)) q=q.Where(x=>x.LeadName.Contains(search)||x.Email.Contains(search)||x.Phone.Contains(search)||(x.CompanyName??"").Contains(search)||x.Status.Contains(search)||x.LeadCode.Contains(search));
        if(!string.IsNullOrWhiteSpace(status)) q=q.Where(x=>EF.Property<string>(x,"Status")==status);
        ViewBag.Search=search; ViewBag.Status=status;
        return View(await q.OrderByDescending(x=>EF.Property<int>(x,"LeadId")).Take(500).ToListAsync());
    }
    public IActionResult Create() => View(new Lead());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Lead item)
    {
        item.LeadCode=string.IsNullOrWhiteSpace(item.LeadCode)?"LEAD-"+Guid.NewGuid().ToString("N")[..8].ToUpper():item.LeadCode;
        
        if(User.IsInRole("SalesExecutive")) item.AssignedTo=User.Identity?.Name;
        if(!new[]{"New", "Contacted", "Qualified", "Unqualified", "Converted", "Lost"}.Contains(item.Status)) ModelState.AddModelError(nameof(item.Status),"Invalid status value.");
        if(!ModelState.IsValid) return View(item);
        _db.Leads.Add(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Create","Lead",item.LeadId.ToString());
        TempData["Message"]="Lead created successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Details(int id) { var item=await _db.Leads.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    public async Task<IActionResult> Edit(int id) { var item=await _db.Leads.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id,Lead item)
    {
        if(id!=item.LeadId) return BadRequest();
        
        
        if(!new[]{"New", "Contacted", "Qualified", "Unqualified", "Converted", "Lost"}.Contains(item.Status)) ModelState.AddModelError(nameof(item.Status),"Invalid status value.");
        if(!ModelState.IsValid) return View(item);
        var existing=await _db.Leads.FindAsync(id); if(existing==null)return NotFound(); if(!CanAccess(existing))return Forbid();
        existing.LeadName=item.LeadName; existing.Email=item.Email; existing.Phone=item.Phone; existing.CompanyName=item.CompanyName; existing.Source=item.Source; existing.Status=item.Status; existing.Priority=item.Priority; existing.ExpectedValue=item.ExpectedValue; if(User.IsInRole("Admin")||User.IsInRole("Manager")) existing.AssignedTo=item.AssignedTo; existing.Notes=item.Notes;
        await _db.SaveChangesAsync(); await _audit.LogAsync("Update","Lead",id.ToString());
        TempData["Message"]="Lead updated successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Delete(int id) { var item=await _db.Leads.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ActionName("Delete"),ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item=await _db.Leads.FindAsync(id); if(item==null)return NotFound();
        if(!User.IsInRole("Admin")&&!User.IsInRole("Manager")) return Forbid();
        _db.Leads.Remove(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Delete","Lead",id.ToString());
        TempData["Message"]="Lead deleted successfully.";
        return RedirectToAction(nameof(Index));
    }
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Convert(int id)
    {
        var lead=await _db.Leads.FindAsync(id); if(lead==null)return NotFound(); if(!CanAccess(lead))return Forbid();
        if(lead.Status!="Qualified") { TempData["Message"]="Only qualified leads can be converted."; return RedirectToAction(nameof(Index)); }
        var existing=await _db.Customers.FirstOrDefaultAsync(x=>x.Email==lead.Email||x.Phone==lead.Phone);
        if(existing!=null) { TempData["Message"]="A customer with this email or phone already exists. Review the customer before converting."; return RedirectToAction(nameof(Index)); }
        var customer=new Customer { CustomerCode="CUS-"+Guid.NewGuid().ToString("N")[..8].ToUpper(),CustomerName=lead.LeadName,Email=lead.Email,Phone=lead.Phone,CompanyName=lead.CompanyName,Status="Active",CreatedBy=User.Identity?.Name,OwnerId=User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value };
        _db.Customers.Add(customer); await _db.SaveChangesAsync();
        if(lead.ExpectedValue>0) _db.Opportunities.Add(new Opportunity { OpportunityName=lead.LeadName+" Opportunity",CustomerId=customer.CustomerId,LeadId=lead.LeadId,Amount=lead.ExpectedValue,Stage="Qualification",Probability=10,ExpectedCloseDate=DateTime.Today.AddDays(30),Status="Open",AssignedTo=lead.AssignedTo });
        lead.Status="Converted"; await _db.SaveChangesAsync(); await _audit.LogAsync("Convert Lead","Lead",lead.LeadId.ToString(),newValue:"CustomerId="+customer.CustomerId);
        TempData["Message"]="Lead converted to customer successfully."; return RedirectToAction(nameof(Index));
    }

    private bool CanAccess(Lead item) => !User.IsInRole("SalesExecutive") || (item.AssignedTo==User.Identity?.Name);

}
