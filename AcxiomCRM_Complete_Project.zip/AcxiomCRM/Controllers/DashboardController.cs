using AcxiomCRM.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers;
[Authorize]
public class DashboardController : Controller
{
    private readonly ApplicationDbContext _db; public DashboardController(ApplicationDbContext db)=>_db=db;
    public async Task<IActionResult> Index()
    {
        var customers=_db.Customers.AsQueryable(); var leads=_db.Leads.AsQueryable(); var opportunities=_db.Opportunities.AsQueryable(); var followups=_db.FollowUps.AsQueryable();
        if(User.IsInRole("SalesExecutive")){var uid=User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)!.Value;var email=User.Identity!.Name;customers=customers.Where(x=>x.OwnerId==uid);leads=leads.Where(x=>x.AssignedTo==email);opportunities=opportunities.Where(x=>x.AssignedTo==email);followups=followups.Where(x=>x.AssignedTo==email);}
        ViewBag.Customers=await customers.CountAsync();
        ViewBag.Leads=await leads.CountAsync();
        ViewBag.OpenLeads=await leads.CountAsync(x=>x.Status!="Lost"&&x.Status!="Converted"&&x.Status!="Unqualified");
        ViewBag.Opportunities=await opportunities.CountAsync();
        ViewBag.OpenOpportunities=await opportunities.CountAsync(x=>x.Status=="Open");
        ViewBag.Won=await opportunities.CountAsync(x=>x.Stage=="Won");
        ViewBag.Lost=await opportunities.CountAsync(x=>x.Stage=="Lost");
        ViewBag.Pipeline=await opportunities.Where(x=>x.Status=="Open").SumAsync(x=>(decimal?)x.Amount)??0m;
        ViewBag.LeadLabels=new[]{"New","Contacted","Qualified","Lost","Converted"};
        ViewBag.LeadValues=await Task.WhenAll(new[]{"New","Contacted","Qualified","Lost","Converted"}.Select(s=>leads.CountAsync(x=>x.Status==s)));
        ViewBag.StageLabels=new[]{"Qualification","Proposal","Negotiation","Won","Lost"};
        ViewBag.StageValues=await Task.WhenAll(new[]{"Qualification","Proposal","Negotiation","Won","Lost"}.Select(s=>opportunities.CountAsync(x=>x.Stage==s)));
        ViewBag.Upcoming=await followups.Where(x=>x.Status=="Planned").OrderBy(x=>x.FollowUpDate).Take(8).ToListAsync();
        return View();
    }
}
