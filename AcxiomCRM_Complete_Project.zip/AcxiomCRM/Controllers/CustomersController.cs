using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers;
[Authorize]
public class CustomersController : Controller
{
    private readonly ApplicationDbContext _db; private readonly IAuditService _audit;
    public CustomersController(ApplicationDbContext db, IAuditService audit) { _db=db; _audit=audit; }
    public async Task<IActionResult> Index(string? search, string? status)
    {
        var q=_db.Customers.AsQueryable();
        if(User.IsInRole("SalesExecutive")) q=q.Where(x=>x.OwnerId==User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)!.Value);
        if(!string.IsNullOrWhiteSpace(search)) q=q.Where(x=>x.CustomerName.Contains(search)||x.Email.Contains(search)||x.Phone.Contains(search)||(x.CompanyName??"").Contains(search)||x.CustomerCode.Contains(search));
        if(!string.IsNullOrWhiteSpace(status)) q=q.Where(x=>EF.Property<string>(x,"Status")==status);
        ViewBag.Search=search; ViewBag.Status=status;
        return View(await q.OrderByDescending(x=>EF.Property<int>(x,"CustomerId")).Take(500).ToListAsync());
    }
    public IActionResult Create() => View(new Customer());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Customer item)
    {
        item.CustomerCode=string.IsNullOrWhiteSpace(item.CustomerCode)?"CUS-"+Guid.NewGuid().ToString("N")[..8].ToUpper():item.CustomerCode;
        
        if(!new[]{"Active", "Inactive"}.Contains(item.Status)) ModelState.AddModelError(nameof(item.Status),"Invalid status value.");
        if(!ModelState.IsValid) return View(item);
        
        if(await _db.Customers.AnyAsync(x=>x.Email==item.Email||x.Phone==item.Phone)) ModelState.AddModelError("","A customer with this email or phone already exists.");
        item.CreatedBy=User.Identity?.Name; item.OwnerId=User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if(!ModelState.IsValid) return View(item);
        _db.Customers.Add(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Create","Customer",item.CustomerId.ToString());
        TempData["Message"]="Customer created successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Details(int id) { var item=await _db.Customers.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    public async Task<IActionResult> Edit(int id) { var item=await _db.Customers.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id,Customer item)
    {
        if(id!=item.CustomerId) return BadRequest();
        
        
        if(await _db.Customers.AnyAsync(x=>x.CustomerId!=id&&(x.Email==item.Email||x.Phone==item.Phone))) ModelState.AddModelError("","Email and phone must be unique.");
        if(!new[]{"Active", "Inactive"}.Contains(item.Status)) ModelState.AddModelError(nameof(item.Status),"Invalid status value.");
        if(!ModelState.IsValid) return View(item);
        var existing=await _db.Customers.FindAsync(id); if(existing==null)return NotFound(); if(!CanAccess(existing))return Forbid();
        existing.CustomerName=item.CustomerName; existing.Email=item.Email; existing.Phone=item.Phone; existing.CompanyName=item.CompanyName; existing.Address=item.Address; existing.City=item.City; existing.State=item.State; existing.Status=item.Status; existing.ModifiedDate=DateTime.UtcNow;
        await _db.SaveChangesAsync(); await _audit.LogAsync("Update","Customer",id.ToString());
        TempData["Message"]="Customer updated successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Delete(int id) { var item=await _db.Customers.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ActionName("Delete"),ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item=await _db.Customers.FindAsync(id); if(item==null)return NotFound();
        if(!User.IsInRole("Admin")&&!User.IsInRole("Manager")) return Forbid();
        _db.Customers.Remove(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Delete","Customer",id.ToString());
        TempData["Message"]="Customer deleted successfully.";
        return RedirectToAction(nameof(Index));
    }
    private bool CanAccess(Customer item) => !User.IsInRole("SalesExecutive") || (item.OwnerId==User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);

}
