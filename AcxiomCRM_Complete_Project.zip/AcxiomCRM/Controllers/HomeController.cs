using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace AcxiomCRM.Controllers;
public class HomeController : Controller
{
    [AllowAnonymous] public IActionResult Error() => View();
}
