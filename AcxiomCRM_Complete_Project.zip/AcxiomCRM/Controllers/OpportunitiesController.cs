using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers;
[Authorize]
public class OpportunitiesController : Controller
{
    private readonly ApplicationDbContext _db; private readonly IAuditService _audit;
    public OpportunitiesController(ApplicationDbContext db, IAuditService audit) { _db=db; _audit=audit; }
    public async Task<IActionResult> Index(string? search, string? status)
    {
        var q=_db.Opportunities.AsQueryable();
        if(User.IsInRole("SalesExecutive")) q=q.Where(x=>x.AssignedTo==User.Identity!.Name);
        if(!string.IsNullOrWhiteSpace(search)) q=q.Where(x=>x.OpportunityName.Contains(search)||x.Stage.Contains(search)||x.Status.Contains(search));
        if(!string.IsNullOrWhiteSpace(status)) q=q.Where(x=>EF.Property<string>(x,"Status")==status);
        ViewBag.Search=search; ViewBag.Status=status;
        return View(await q.OrderByDescending(x=>EF.Property<int>(x,"OpportunityId")).Take(500).ToListAsync());
    }
    public IActionResult Create() => View(new Opportunity());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Opportunity item)
    {
        
        
        if(item.CustomerId.HasValue&&!await _db.Customers.AnyAsync(x=>x.CustomerId==item.CustomerId)) ModelState.AddModelError(nameof(item.CustomerId),"Selected customer does not exist.");
        if(item.LeadId.HasValue&&!await _db.Leads.AnyAsync(x=>x.LeadId==item.LeadId)) ModelState.AddModelError(nameof(item.LeadId),"Selected lead does not exist.");
        if(item.Amount<=0) ModelState.AddModelError(nameof(item.Amount),"Opportunity Amount must be greater than 0.");
        if(item.Probability<0||item.Probability>100) ModelState.AddModelError(nameof(item.Probability),"Probability must be between 0 and 100.");
        if(item.Status=="Open"&&item.ExpectedCloseDate.Date<DateTime.Today) ModelState.AddModelError(nameof(item.ExpectedCloseDate),"Expected Close Date cannot be in the past.");
        if(User.IsInRole("SalesExecutive")) item.AssignedTo=User.Identity?.Name;
        if(!new[]{"Qualification", "Proposal", "Negotiation", "Won", "Lost"}.Contains(item.Stage)) ModelState.AddModelError(nameof(item.Stage),"Invalid stage value.");
        if(!ModelState.IsValid) return View(item);
        _db.Opportunities.Add(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Create","Opportunity",item.OpportunityId.ToString());
        TempData["Message"]="Opportunity created successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Details(int id) { var item=await _db.Opportunities.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    public async Task<IActionResult> Edit(int id) { var item=await _db.Opportunities.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id,Opportunity item)
    {
        if(id!=item.OpportunityId) return BadRequest();
        
        if(item.CustomerId.HasValue&&!await _db.Customers.AnyAsync(x=>x.CustomerId==item.CustomerId)) ModelState.AddModelError(nameof(item.CustomerId),"Selected customer does not exist.");
        if(item.LeadId.HasValue&&!await _db.Leads.AnyAsync(x=>x.LeadId==item.LeadId)) ModelState.AddModelError(nameof(item.LeadId),"Selected lead does not exist.");
        if(item.Amount<=0) ModelState.AddModelError(nameof(item.Amount),"Opportunity Amount must be greater than 0.");
        if(item.Probability<0||item.Probability>100) ModelState.AddModelError(nameof(item.Probability),"Probability must be between 0 and 100.");
        if(item.Status=="Open"&&item.ExpectedCloseDate.Date<DateTime.Today) ModelState.AddModelError(nameof(item.ExpectedCloseDate),"Expected Close Date cannot be in the past.");
        
        if(!new[]{"Qualification", "Proposal", "Negotiation", "Won", "Lost"}.Contains(item.Stage)) ModelState.AddModelError(nameof(item.Stage),"Invalid stage value.");
        if(!ModelState.IsValid) return View(item);
        var existing=await _db.Opportunities.FindAsync(id); if(existing==null)return NotFound(); if(!CanAccess(existing))return Forbid();
        existing.OpportunityName=item.OpportunityName; existing.CustomerId=item.CustomerId; existing.LeadId=item.LeadId; existing.Amount=item.Amount; existing.Stage=item.Stage; existing.Probability=item.Probability; existing.ExpectedCloseDate=item.ExpectedCloseDate; existing.Status=item.Status; if(User.IsInRole("Admin")||User.IsInRole("Manager")) existing.AssignedTo=item.AssignedTo; existing.Notes=item.Notes;
        await _db.SaveChangesAsync(); await _audit.LogAsync("Update","Opportunity",id.ToString());
        TempData["Message"]="Opportunity updated successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Delete(int id) { var item=await _db.Opportunities.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ActionName("Delete"),ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item=await _db.Opportunities.FindAsync(id); if(item==null)return NotFound();
        if(!User.IsInRole("Admin")&&!User.IsInRole("Manager")) return Forbid();
        _db.Opportunities.Remove(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Delete","Opportunity",id.ToString());
        TempData["Message"]="Opportunity deleted successfully.";
        return RedirectToAction(nameof(Index));
    }
    private bool CanAccess(Opportunity item) => !User.IsInRole("SalesExecutive") || (item.AssignedTo==User.Identity?.Name);

}
