using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers;
[Authorize]
public class FollowUpsController : Controller
{
    private readonly ApplicationDbContext _db; private readonly IAuditService _audit;
    public FollowUpsController(ApplicationDbContext db, IAuditService audit) { _db=db; _audit=audit; }
    public async Task<IActionResult> Index(string? search, string? status)
    {
        var q=_db.FollowUps.AsQueryable();
        if(User.IsInRole("SalesExecutive")) q=q.Where(x=>x.AssignedTo==User.Identity!.Name);
        if(!string.IsNullOrWhiteSpace(search)) q=q.Where(x=>x.Subject.Contains(search)||x.FollowUpType.Contains(search)||x.Status.Contains(search)||(x.Remarks??"").Contains(search));
        if(!string.IsNullOrWhiteSpace(status)) q=q.Where(x=>EF.Property<string>(x,"Status")==status);
        ViewBag.Search=search; ViewBag.Status=status;
        return View(await q.OrderByDescending(x=>EF.Property<int>(x,"FollowUpId")).Take(500).ToListAsync());
    }
    public IActionResult Create() => View(new FollowUp());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(FollowUp item)
    {
        
        
        if(item.Status=="Planned"&&item.FollowUpDate.Date<DateTime.Today) ModelState.AddModelError(nameof(item.FollowUpDate),"Follow-up date cannot be earlier than today.");
        if(User.IsInRole("SalesExecutive")) item.AssignedTo=User.Identity?.Name;
        if(!new[]{"Planned", "Completed", "Missed", "Cancelled"}.Contains(item.Status)) ModelState.AddModelError(nameof(item.Status),"Invalid status value.");
        if(!ModelState.IsValid) return View(item);
        _db.FollowUps.Add(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Create","FollowUp",item.FollowUpId.ToString());
        TempData["Message"]="FollowUp created successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Details(int id) { var item=await _db.FollowUps.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    public async Task<IActionResult> Edit(int id) { var item=await _db.FollowUps.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id,FollowUp item)
    {
        if(id!=item.FollowUpId) return BadRequest();
        
        if(item.Status=="Planned"&&item.FollowUpDate.Date<DateTime.Today) ModelState.AddModelError(nameof(item.FollowUpDate),"Follow-up date cannot be earlier than today.");
        
        if(!new[]{"Planned", "Completed", "Missed", "Cancelled"}.Contains(item.Status)) ModelState.AddModelError(nameof(item.Status),"Invalid status value.");
        if(!ModelState.IsValid) return View(item);
        var existing=await _db.FollowUps.FindAsync(id); if(existing==null)return NotFound(); if(!CanAccess(existing))return Forbid();
        existing.CustomerId=item.CustomerId; existing.LeadId=item.LeadId; existing.FollowUpDate=item.FollowUpDate; existing.FollowUpType=item.FollowUpType; existing.Subject=item.Subject; existing.Remarks=item.Remarks; existing.Status=item.Status; if(User.IsInRole("Admin")||User.IsInRole("Manager")) existing.AssignedTo=item.AssignedTo;
        await _db.SaveChangesAsync(); await _audit.LogAsync("Update","FollowUp",id.ToString());
        TempData["Message"]="FollowUp updated successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Delete(int id) { var item=await _db.FollowUps.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ActionName("Delete"),ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item=await _db.FollowUps.FindAsync(id); if(item==null)return NotFound();
        if(!User.IsInRole("Admin")&&!User.IsInRole("Manager")) return Forbid();
        _db.FollowUps.Remove(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Delete","FollowUp",id.ToString());
        TempData["Message"]="FollowUp deleted successfully.";
        return RedirectToAction(nameof(Index));
    }
    private bool CanAccess(FollowUp item) => !User.IsInRole("SalesExecutive") || (item.AssignedTo==User.Identity?.Name);

}
