using AcxiomCRM.Models;using AcxiomCRM.Services;using Microsoft.AspNetCore.Authorization;using Microsoft.AspNetCore.Identity;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.RateLimiting;using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Controllers.Api;
[ApiController,Route("api/auth")]
public class AuthApiController:ControllerBase
{
 private readonly SignInManager<ApplicationUser> _signIn;private readonly UserManager<ApplicationUser> _users;private readonly IAuditService _audit;
 public AuthApiController(SignInManager<ApplicationUser> signIn,UserManager<ApplicationUser> users,IAuditService audit){_signIn=signIn;_users=users;_audit=audit;}
 [AllowAnonymous,HttpPost("login"),EnableRateLimiting("auth")] public async Task<IActionResult> Login([FromBody]ApiLoginRequest request){if(!ModelState.IsValid)return ValidationProblem(ModelState);var user=await _users.FindByEmailAsync(request.Email);if(user==null){await _audit.LogAsync("Failed Login","Authentication",result:"Failure",details:"Invalid credentials");return Unauthorized(new{message="Invalid email or password."});}var result=await _signIn.PasswordSignInAsync(user.UserName!,request.Password,isPersistent:false,lockoutOnFailure:true);if(!result.Succeeded){await _audit.LogAsync("Failed Login","Authentication",user.Id,result:"Failure",details:result.IsLockedOut?"Account locked":"Invalid credentials");return Unauthorized(new{message=result.IsLockedOut?"Account locked. Try again later.":"Invalid email or password."});}await _audit.LogAsync("Login","Authentication",user.Id);return Ok(new{message="Login successful.",user=new{id=user.Id,name=user.FullName,email=user.Email}});}
 [Authorize,HttpPost("logout")] public async Task<IActionResult> Logout(){await _audit.LogAsync("Logout","Authentication");await _signIn.SignOutAsync();return Ok(new{message="Logged out."});}
}
public class ApiLoginRequest{[Required,EmailAddress]public string Email{get;set;}="";[Required]public string Password{get;set;}="";}
