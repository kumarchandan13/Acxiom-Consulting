using AcxiomCRM.Data;using Microsoft.AspNetCore.Authorization;using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers.Api;
[ApiController,Route("api/reports"),Authorize(Roles="Admin,Manager")]
public class ReportsApiController:ControllerBase
{
 private readonly ApplicationDbContext _db;public ReportsApiController(ApplicationDbContext db)=>_db=db;
 [HttpGet("pipeline")] public async Task<IActionResult> Pipeline(){var rows=await _db.Opportunities.Where(x=>x.Status=="Open").GroupBy(x=>x.Stage).Select(g=>new{Stage=g.Key,Count=g.Count(),Amount=g.Sum(x=>x.Amount),WeightedAmount=g.Sum(x=>x.Amount*x.Probability/100m)}).ToListAsync();return Ok(new{generatedAt=DateTime.UtcNow,stages=rows,totalAmount=rows.Sum(x=>x.Amount),totalWeightedAmount=rows.Sum(x=>x.WeightedAmount)});}
}
