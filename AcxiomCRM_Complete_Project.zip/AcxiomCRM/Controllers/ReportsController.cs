using AcxiomCRM.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text;
namespace AcxiomCRM.Controllers;
[Authorize]
public class ReportsController : Controller
{
    private readonly ApplicationDbContext _db;
    public ReportsController(ApplicationDbContext db) => _db=db;
    public IActionResult Index() => View();
    [Authorize(Roles="Admin,Manager,SalesExecutive")]
    public async Task<IActionResult> Customers(string? status)
    {
        var q=_db.Customers.AsQueryable(); if(!string.IsNullOrWhiteSpace(status))q=q.Where(x=>x.Status==status);
        if(User.IsInRole("SalesExecutive")){var uid=User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)!.Value;q=q.Where(x=>x.OwnerId==uid);}
        ViewBag.Title="Customer Report";ViewBag.Filter=status;var data=await q.OrderBy(x=>x.CustomerName).Take(1000).ToListAsync();ViewBag.Rows=data.Select(x=>new[]{x.CustomerName,x.Email,x.Phone,x.Status,x.CreatedDate.ToString("yyyy-MM-dd")}).ToList();return View("Table");
    }
    public async Task<IActionResult> Leads(string? status)
    {
        var q=_db.Leads.AsQueryable();if(!string.IsNullOrWhiteSpace(status))q=q.Where(x=>x.Status==status);if(User.IsInRole("SalesExecutive"))q=q.Where(x=>x.AssignedTo==User.Identity!.Name);
        ViewBag.Title="Lead Report";ViewBag.Filter=status;var data=await q.OrderByDescending(x=>x.CreatedDate).Take(1000).ToListAsync();ViewBag.Rows=data.Select(x=>new[]{x.LeadName,x.Source,x.Status,x.Priority,x.AssignedTo??"",x.CreatedDate.ToString("yyyy-MM-dd")}).ToList();return View("Table");
    }
    public async Task<IActionResult> FollowUps(string? status)
    {
        var q=_db.FollowUps.AsQueryable();if(!string.IsNullOrWhiteSpace(status))q=q.Where(x=>x.Status==status);if(User.IsInRole("SalesExecutive"))q=q.Where(x=>x.AssignedTo==User.Identity!.Name);
        ViewBag.Title="Follow-Up Report";ViewBag.Filter=status;var data=await q.OrderBy(x=>x.FollowUpDate).Take(1000).ToListAsync();ViewBag.Rows=data.Select(x=>new[]{x.Subject,x.FollowUpType,x.Status,x.AssignedTo??"",x.FollowUpDate.ToString("yyyy-MM-dd"),x.FollowUpDate.Date<DateTime.Today&&x.Status=="Planned"?"Overdue":"No"}).ToList();return View("Table");
    }
    public async Task<IActionResult> Opportunities(string? stage)
    {
        var q=_db.Opportunities.AsQueryable();if(!string.IsNullOrWhiteSpace(stage))q=q.Where(x=>x.Stage==stage);if(User.IsInRole("SalesExecutive"))q=q.Where(x=>x.AssignedTo==User.Identity!.Name);
        ViewBag.Title="Opportunity Report";ViewBag.Filter=stage;var data=await q.OrderBy(x=>x.ExpectedCloseDate).Take(1000).ToListAsync();ViewBag.Rows=data.Select(x=>new[]{x.OpportunityName,x.Stage,x.Amount.ToString("0.00"),x.Probability.ToString(),(x.Amount*x.Probability/100m).ToString("0.00"),x.ExpectedCloseDate.ToString("yyyy-MM-dd")}).ToList();return View("Table");
    }
    [Authorize(Roles="Admin,Manager")]
    public async Task<IActionResult> Pipeline()
    {
        ViewBag.Title="Pipeline Report";ViewBag.Filter="";var data=await _db.Opportunities.Where(x=>x.Status=="Open").GroupBy(x=>new{x.Stage,x.AssignedTo}).Select(g=>new{g.Key.Stage,g.Key.AssignedTo,Count=g.Count(),Amount=g.Sum(x=>x.Amount),Weighted=g.Sum(x=>x.Amount*x.Probability/100m)}).ToListAsync();ViewBag.Rows=data.Select(x=>new[]{x.Stage,x.AssignedTo??"Unassigned",x.Count.ToString(),x.Amount.ToString("0.00"),x.Weighted.ToString("0.00")}).ToList();return View("Table");
    }
    [Authorize(Roles="Admin,Manager")]
    public async Task<IActionResult> Conversion()
    {
        ViewBag.Title="Lead Conversion Report";ViewBag.Filter="";var data=await _db.Leads.GroupBy(x=>x.Status).Select(g=>new{Status=g.Key,Count=g.Count()}).ToListAsync();ViewBag.Rows=data.Select(x=>new[]{x.Status,x.Count.ToString()}).ToList();return View("Table");
    }
    [Authorize(Roles="Admin")]
    public async Task<IActionResult> Audit()
    {
        ViewBag.Title="Audit Report";ViewBag.Filter="";var data=await _db.AuditLogs.OrderByDescending(x=>x.CreatedDate).Take(1000).ToListAsync();ViewBag.Rows=data.Select(x=>new[]{x.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss"),x.UserId??"",x.Action,x.EntityName,x.RecordId??"",x.Result}).ToList();return View("Table");
    }
    [Authorize(Roles="Admin,Manager")]
    public async Task<IActionResult> UserActivity()
    {
        ViewBag.Title="User Activity Report";ViewBag.Filter="";var data=await _db.AuditLogs.GroupBy(x=>x.UserId).Select(g=>new{UserId=g.Key,Count=g.Count(),LastSeen=g.Max(x=>x.CreatedDate)}).ToListAsync();ViewBag.Rows=data.Select(x=>new[]{x.UserId??"Unknown",x.Count.ToString(),x.LastSeen.ToString("yyyy-MM-dd HH:mm:ss")}).ToList();return View("Table");
    }
    [Authorize(Roles="Admin,Manager")]
    public async Task<IActionResult> ExportCustomers()
    {
        var data=await _db.Customers.OrderBy(x=>x.CustomerName).ToListAsync();var rows=data.Select(x=>new[]{x.CustomerName,x.Email,x.Phone,x.Status,x.CreatedDate.ToString("yyyy-MM-dd")}).ToList();
        var csv=new StringBuilder("Name,Email,Phone,Status,CreatedDate\r\n");foreach(var row in rows)csv.AppendLine(string.Join(',',row.Select(v=>"\""+(v??"").Replace("\"","\"\"")+"\"")));
        return File(Encoding.UTF8.GetBytes(csv.ToString()),"text/csv","customers-report.csv");
    }
}
