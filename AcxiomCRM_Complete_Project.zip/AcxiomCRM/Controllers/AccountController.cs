using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Controllers;
public class AccountController : Controller
{
    private readonly SignInManager<ApplicationUser> _signIn; private readonly UserManager<ApplicationUser> _users; private readonly IAuditService _audit;
    public AccountController(SignInManager<ApplicationUser> signIn, UserManager<ApplicationUser> users, IAuditService audit) { _signIn=signIn; _users=users; _audit=audit; }
    [HttpGet,Microsoft.AspNetCore.Authorization.AllowAnonymous] public IActionResult Login(string? returnUrl=null) { ViewBag.ReturnUrl=returnUrl; return View(); }
    [HttpPost,Microsoft.AspNetCore.Authorization.AllowAnonymous,ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginVm vm,string? returnUrl=null)
    {
        if(!ModelState.IsValid) return View(vm);
        var user=await _users.FindByNameAsync(vm.Email) ?? await _users.FindByEmailAsync(vm.Email);
        var result=await _signIn.PasswordSignInAsync(vm.Email,vm.Password,vm.RememberMe,lockoutOnFailure:true);
        if(result.Succeeded) { await _audit.LogAsync("Login","Authentication",user?.Id); return LocalRedirect(returnUrl ?? Url.Action("Index","Dashboard")!); }
        await _audit.LogAsync("Failed Login","Authentication",user?.Id,result:"Failure",details:result.IsLockedOut?"Account locked":"Invalid credentials");
        ModelState.AddModelError("",result.IsLockedOut?"Account locked. Try again later.":"Invalid login attempt.");
        return View(vm);
    }
    [HttpGet,Microsoft.AspNetCore.Authorization.AllowAnonymous] public IActionResult Register()=>View();
    [HttpPost,Microsoft.AspNetCore.Authorization.AllowAnonymous,ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterVm vm)
    {
        if(!ModelState.IsValid)return View(vm);
        var user=new ApplicationUser{UserName=vm.Email,Email=vm.Email,FullName=vm.FullName,EmailConfirmed=true};
        var result=await _users.CreateAsync(user,vm.Password);
        if(result.Succeeded){ await _users.AddToRoleAsync(user,"SalesExecutive"); await _audit.LogAsync("Register","Authentication",user.Id); await _signIn.SignInAsync(user,false); return RedirectToAction("Index","Dashboard");}
        foreach(var e in result.Errors) ModelState.AddModelError("",e.Description);
        return View(vm);
    }
    [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Logout(){ await _audit.LogAsync("Logout","Authentication"); await _signIn.SignOutAsync(); return RedirectToAction("Login"); }
    [HttpGet,Microsoft.AspNetCore.Authorization.AllowAnonymous] public IActionResult AccessDenied()=>View();
}
public class LoginVm { [Required,EmailAddress] public string Email{get;set;}=""; [Required,DataType(DataType.Password)] public string Password{get;set;}=""; public bool RememberMe{get;set;} }
public class RegisterVm { [Required,StringLength(100)] public string FullName{get;set;}=""; [Required,EmailAddress] public string Email{get;set;}=""; [Required,MinLength(8),DataType(DataType.Password)] public string Password{get;set;}=""; [Required,Compare(nameof(Password)),DataType(DataType.Password)] public string ConfirmPassword{get;set;}=""; }
