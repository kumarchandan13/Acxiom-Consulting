using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers;
[Authorize]
public class ActivitiesController : Controller
{
    private readonly ApplicationDbContext _db; private readonly IAuditService _audit;
    public ActivitiesController(ApplicationDbContext db, IAuditService audit) { _db=db; _audit=audit; }
    public async Task<IActionResult> Index(string? search, string? status)
    {
        var q=_db.Activities.AsQueryable();
        if(User.IsInRole("SalesExecutive")) q=q.Where(x=>x.AssignedTo==User.Identity!.Name);
        if(!string.IsNullOrWhiteSpace(search)) q=q.Where(x=>x.Subject.Contains(search)||x.ActivityType.Contains(search)||x.Status.Contains(search)||(x.Description??"").Contains(search));
        if(!string.IsNullOrWhiteSpace(status)) q=q.Where(x=>EF.Property<string>(x,"Status")==status);
        ViewBag.Search=search; ViewBag.Status=status;
        return View(await q.OrderByDescending(x=>EF.Property<int>(x,"ActivityId")).Take(500).ToListAsync());
    }
    public IActionResult Create() => View(new Activity());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Activity item)
    {
        
        
        if(User.IsInRole("SalesExecutive")) item.AssignedTo=User.Identity?.Name;
        if(!new[]{"Planned", "Completed", "Cancelled"}.Contains(item.Status)) ModelState.AddModelError(nameof(item.Status),"Invalid status value.");
        if(!ModelState.IsValid) return View(item);
        _db.Activities.Add(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Create","Activity",item.ActivityId.ToString());
        TempData["Message"]="Activity created successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Details(int id) { var item=await _db.Activities.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    public async Task<IActionResult> Edit(int id) { var item=await _db.Activities.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id,Activity item)
    {
        if(id!=item.ActivityId) return BadRequest();
        
        
        if(!new[]{"Planned", "Completed", "Cancelled"}.Contains(item.Status)) ModelState.AddModelError(nameof(item.Status),"Invalid status value.");
        if(!ModelState.IsValid) return View(item);
        var existing=await _db.Activities.FindAsync(id); if(existing==null)return NotFound(); if(!CanAccess(existing))return Forbid();
        existing.ActivityType=item.ActivityType; existing.Subject=item.Subject; existing.Description=item.Description; existing.ActivityDate=item.ActivityDate; existing.CustomerId=item.CustomerId; existing.LeadId=item.LeadId; if(User.IsInRole("Admin")||User.IsInRole("Manager")) existing.AssignedTo=item.AssignedTo; existing.Status=item.Status;
        await _db.SaveChangesAsync(); await _audit.LogAsync("Update","Activity",id.ToString());
        TempData["Message"]="Activity updated successfully.";
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Delete(int id) { var item=await _db.Activities.FindAsync(id); if(item==null)return NotFound(); if(!CanAccess(item))return Forbid(); return View(item); }
    [HttpPost,ActionName("Delete"),ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item=await _db.Activities.FindAsync(id); if(item==null)return NotFound();
        if(!User.IsInRole("Admin")&&!User.IsInRole("Manager")) return Forbid();
        _db.Activities.Remove(item); await _db.SaveChangesAsync(); await _audit.LogAsync("Delete","Activity",id.ToString());
        TempData["Message"]="Activity deleted successfully.";
        return RedirectToAction(nameof(Index));
    }
    private bool CanAccess(Activity item) => !User.IsInRole("SalesExecutive") || (item.AssignedTo==User.Identity?.Name);

}
