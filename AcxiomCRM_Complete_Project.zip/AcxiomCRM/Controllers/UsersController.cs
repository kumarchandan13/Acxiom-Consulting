using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers;
[Authorize(Roles="Admin")]
public class UsersController : Controller
{
    private readonly UserManager<ApplicationUser> _users; private readonly IAuditService _audit;
    public UsersController(UserManager<ApplicationUser> users,IAuditService audit){_users=users;_audit=audit;}
    public async Task<IActionResult> Index(){var users=await _users.Users.OrderBy(x=>x.Email).ToListAsync();var roles=new Dictionary<string,string>();foreach(var user in users){var assigned=await _users.GetRolesAsync(user);roles[user.Id]=assigned.FirstOrDefault()??"Unassigned";}ViewBag.UserRoles=roles;return View(users);}
    public IActionResult Create()=>View(new CreateUserVm());
    [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Create(CreateUserVm vm){
        if(!ModelState.IsValid)return View(vm);
        var u=new ApplicationUser{UserName=vm.Email,Email=vm.Email,FullName=vm.FullName,EmailConfirmed=true};
        var r=await _users.CreateAsync(u,vm.Password);
        if(r.Succeeded){await _users.AddToRoleAsync(u,vm.Role);await _audit.LogAsync("Create User","User",u.Id,newValue:vm.Role);return RedirectToAction(nameof(Index));}
        foreach(var e in r.Errors)ModelState.AddModelError("",e.Description);return View(vm);
    }
    [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> SetRole(string id,string role){if(!new[]{"Admin","Manager","SalesExecutive"}.Contains(role))return BadRequest();var u=await _users.FindByIdAsync(id);if(u==null)return NotFound();if(u.Id==_users.GetUserId(User)&&role!="Admin"){TempData["Message"]="You cannot remove your own Admin role.";return RedirectToAction(nameof(Index));}var old=await _users.GetRolesAsync(u);var remove=await _users.RemoveFromRolesAsync(u,old);if(!remove.Succeeded){TempData["Message"]="Could not update role.";return RedirectToAction(nameof(Index));}var result=await _users.AddToRoleAsync(u,role);await _audit.LogAsync("Change Role","User",id,oldValue:string.Join(",",old),newValue:role,result:result.Succeeded?"Success":"Failure");TempData["Message"]=result.Succeeded?"Role updated.":"Role update failed.";return RedirectToAction(nameof(Index));}
    [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Toggle(string id){var u=await _users.FindByIdAsync(id);if(u==null)return NotFound();if(u.Id==_users.GetUserId(User)){TempData["Message"]="You cannot lock your own account.";return RedirectToAction(nameof(Index));}u.LockoutEnabled=true;u.LockoutEnd=(u.LockoutEnd.HasValue && u.LockoutEnd.Value>DateTimeOffset.UtcNow)?null:DateTimeOffset.UtcNow.AddYears(50);await _users.UpdateAsync(u);await _audit.LogAsync("Toggle User","User",id);return RedirectToAction(nameof(Index));}
}
public class CreateUserVm{[System.ComponentModel.DataAnnotations.Required]public string FullName{get;set;}="";[System.ComponentModel.DataAnnotations.Required, System.ComponentModel.DataAnnotations.EmailAddress]public string Email{get;set;}="";[System.ComponentModel.DataAnnotations.Required,System.ComponentModel.DataAnnotations.MinLength(8)]public string Password{get;set;}="";[System.ComponentModel.DataAnnotations.Required]public string Role{get;set;}="SalesExecutive";}
