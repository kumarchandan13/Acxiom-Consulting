$ErrorActionPreference = 'Stop'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
  Write-Error '.NET 8 SDK was not found. Install it from https://dotnet.microsoft.com/download/dotnet/8.0 and reopen PowerShell.'
}
dotnet --version
dotnet restore .\AcxiomCRM.csproj
dotnet run --project .\AcxiomCRM.csproj
