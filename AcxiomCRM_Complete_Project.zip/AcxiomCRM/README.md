# AcxiomCRM — ASP.NET Core MVC CRM

A structured starter implementation based on the supplied **AcxiomCRM Complete Project Assignment**. It uses ASP.NET Core 8 MVC, ASP.NET Core Identity, Entity Framework Core + SQLite, Bootstrap 5, Chart.js, MVC validation, audit records and protected REST endpoints.

## Prerequisites
- .NET 8 SDK
- Visual Studio 2022 (ASP.NET and web development workload) or VS Code + C# Dev Kit
- Internet connection for Bootstrap/Chart.js/jQuery CDN assets (or vendor them locally for offline use)

## Run
Windows PowerShell:
```powershell
cd AcxiomCRM
.\run-local.ps1
```

Or use a terminal on Windows/macOS/Linux:
```bash
cd AcxiomCRM
dotnet restore
dotnet run
```
The project includes `run-local.ps1` and `run-local.sh` convenience scripts.
Open the HTTPS/HTTP URL shown in the terminal. The database `acxiomcrm.db` is created automatically on first run.

**Seeded development administrator**
- Email: `admin@acxiomcrm.local`
- Password: `Admin@12345`

Change this password and replace the seed strategy before deployment. The seeded account is for local evaluation only.

## Main modules
- Authentication: Identity login/register/logout, hashed passwords, password policy, lockout, cookie auth, anti-forgery on MVC POSTs.
- Dashboard: scoped-ready KPI cards, Lead Status and Opportunity Pipeline Chart.js charts, upcoming follow-ups.
- Customers, Leads, Opportunities, Follow-Ups and Activities: MVC CRUD views, search/filter inputs, model validation, audit logging.
- Users: Admin-only user creation, role assignment and account lock/unlock controls.
- Audit Log: Admin-only audit event search.
- REST API: `/api/customers` (GET/GET by ID/POST/PUT/DELETE-deactivate), `/api/leads` (GET/POST), `/api/opportunities` (GET/POST).
- Data: Identity tables plus Customer, Lead, Opportunity, FollowUp, Activity and AuditLog.

## Visual Studio
Open `AcxiomCRM.sln` in Visual Studio 2022, restore NuGet packages, then press F5. The launch profile uses `https://localhost:7188` and `http://localhost:5188`.

## Important implementation notes
1. Identity is used for authentication; no custom password table exists.
2. Customer email and phone have unique database indexes. Duplicate checks are also performed in MVC/API code.
3. Opportunity amount/probability/close date and planned follow-up date have server-side business validation.
4. Anti-forgery validation is applied to state-changing MVC form posts.
5. API endpoints require authentication. Use an authenticated browser session or add a separately configured bearer-token scheme for external clients.
6. Roles are `Admin`, `Manager`, and `SalesExecutive`. Registration assigns SalesExecutive. The Admin user is seeded. Managers are intentionally not given user/role administration.
7. This is a local development baseline, not a production deployment. Sales Executive record scoping is applied to the primary MVC lists and detail/edit actions; Manager currently represents a broad team view because the specification does not define a team hierarchy. Before production, add migrations and backup strategy, API rate limiting, structured logging/monitoring, HTTPS-only production configuration, secure secrets management, automated tests, email-based password reset, full audit snapshots, and a dedicated bearer-token scheme if APIs will be called by non-browser clients.
8. Some list pages cap results at 500–1,000 rather than providing full pagination. Report exports are implemented for customers only; add exports for the other reports before production.

## Database changes
For iterative development, `EnsureCreated` is convenient. For maintained projects use EF migrations:
```bash
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
```
If switching from `EnsureCreated` to migrations, delete the local `acxiomcrm.db` first during development and remove `EnsureCreatedAsync()` from `Program.cs`.

## Test checklist from the assignment
- Anonymous access redirects to Login.
- Valid login reaches Dashboard; invalid login fails; five failures trigger lockout.
- Register a Sales Executive account.
- Test customer required/email/phone validation and duplicate email/phone prevention.
- Test opportunity amount > 0, probability 0–100, expected close date not in past while Open.
- Test planned follow-up date not in the past.
- Check create/update/delete and authentication audit entries.
- Sign in as Admin and verify Users/Audit Log; non-admin should receive access denied.
- Call the REST API while authenticated and verify JSON / HTTP status codes.
- Confirm dashboard KPIs and charts display.

## Default URLs
- `/Account/Login`
- `/Account/Register`
- `/Dashboard`
- `/Customers`
- `/Leads`
- `/Opportunities`
- `/FollowUps`
- `/Activities`
- `/Users` (Admin)
- `/Audit` (Admin)
- `/api/customers`
- `/api/leads`
- `/api/opportunities`


## Build verification note
The archive was checked for ZIP integrity. This execution environment does not have the .NET SDK installed, so `dotnet restore`, compilation and browser-based end-to-end tests could not be run here. Run the commands above on a machine with the .NET 8 SDK and address any environment-specific NuGet or HTTPS development-certificate prompts.
