document.addEventListener('submit', function(e){const form=e.target;if(form.matches('[data-confirm]')&&!confirm(form.dataset.confirm||'Are you sure?'))e.preventDefault();});
