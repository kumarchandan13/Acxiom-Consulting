#!/usr/bin/env bash
set -euo pipefail
if ! command -v dotnet >/dev/null 2>&1; then
  echo '.NET 8 SDK was not found. Install it from https://dotnet.microsoft.com/download/dotnet/8.0.' >&2
  exit 1
fi
dotnet restore ./AcxiomCRM.csproj
dotnet run --project ./AcxiomCRM.csproj
