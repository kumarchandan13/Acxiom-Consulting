# Manual test plan

1. Browse `/Customers` in a private window. Expect redirect to Login.
2. Register a user; verify the user receives `SalesExecutive`.
3. Login with seeded local Admin and open `/Users` and `/Audit`.
4. Try five invalid login attempts and confirm lockout.
5. Create a customer with malformed email/phone and confirm validation errors.
6. Create two customers using the same email or phone; second must be rejected.
7. Create an Opportunity with amount 0, probability 101, or a past close date while Open; each must be rejected.
8. Create a planned Follow-Up dated yesterday; it must be rejected.
9. Create/update/delete a record and verify an audit row is created.
10. Verify non-admin cannot access `/Users` or `/Audit`.
11. Call customer API while logged in; verify JSON. Try invalid body and duplicate email/phone.
12. Verify dashboard cards and charts render with sample data.
