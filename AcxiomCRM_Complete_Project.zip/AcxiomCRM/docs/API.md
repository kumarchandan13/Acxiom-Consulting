# REST API notes

All endpoints require an authenticated session. API DTOs should be preferred over EF entities. Customer endpoints use a DTO.

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/login` | Login using email/password and receive an authenticated cookie |
| POST | `/api/auth/logout` | End authenticated session |
| GET | `/api/customers?search=` | List/search customers |
| GET | `/api/customers/{id}` | Get one customer |
| POST | `/api/customers` | Create customer |
| PUT | `/api/customers/{id}` | Update customer |
| DELETE | `/api/customers/{id}` | Deactivate customer (Admin/Manager) |
| GET | `/api/leads?search=` | List/search leads |
| POST | `/api/leads` | Create lead |
| GET | `/api/followups?status=` | List follow-ups |
| POST | `/api/followups` | Create follow-up |
| GET | `/api/reports/pipeline` | Pipeline report (Admin/Manager) |
| GET | `/api/opportunities` | List opportunities |
| POST | `/api/opportunities` | Create opportunity |

Example customer POST body:
```json
{
  "customerName": "Aarav Sharma",
  "email": "aarav@example.com",
  "phone": "9876543210",
  "companyName": "Example Pvt Ltd",
  "address": "Bhubaneswar",
  "city": "Bhubaneswar",
  "state": "Odisha",
  "status": "Active"
}
```
Typical statuses: `200 OK`, `201 Created`, `204 No Content`, `400 Bad Request`, `401 Unauthorized`, `403 Forbidden`, `404 Not Found`, `409 Conflict`.
