# Assignment traceability checklist

| Requirement in supplied PDF | Implementation location | Status / notes |
|---|---|---|
| ASP.NET Core Identity | `Program.cs`, `Models/ApplicationUser.cs`, `Data/SeedData.cs` | Implemented |
| Roles Admin / Manager / SalesExecutive | Identity roles + `UsersController` | Role creation and assignment, account lock toggling and Sales Executive ownership scoping implemented; Manager scope is broad because no team hierarchy is defined |
| Login/register/logout | `AccountController`, `Views/Account` | Implemented |
| Password hashing/policy/lockout | Identity options in `Program.cs` | Implemented |
| Customer CRUD and duplicate prevention | `CustomersController`, Customer model, API controller | Implemented baseline |
| Lead CRUD/status/conversion | `LeadsController`, `Lead` | CRUD, status and qualified-lead conversion implemented; transition rules can be expanded |
| Opportunity business rules | `OpportunitiesController`, Opportunities API | Implemented |
| Follow-up business rules | `FollowUpsController` | Implemented |
| Activity management | `ActivitiesController` | Implemented |
| Audit events | `AuditService`, controllers | Core events logged; snapshots/immutability can be strengthened |
| Dashboard KPIs and Chart.js charts | `DashboardController`, `Views/Dashboard/Index.cshtml` | Implemented |
| REST API for authentication, customers, leads, opportunities, follow-ups and pipeline report | `Controllers/Api` | Core endpoints implemented; API uses cookie session authentication in this starter |
| Bootstrap responsive UI | Shared layout and CSS | Implemented |
| Client/server validation | DataAnnotations + unobtrusive validation + server checks | Implemented baseline |
| Search/filter/sort/pagination | CRUD list pages | Search/status filter present; field-specific filters/pagination/sorting need completion |
| Reports: customer/lead/follow-up/opportunity/pipeline/conversion/user activity/audit | `ReportsController`, `Views/Reports`, pipeline API | Core report pages and customer CSV export implemented; additional exports, pagination and richer filtering remain enhancement items |
| Ownership/team data scoping | Service/query layer | Must be completed before production and for full assignment acceptance |
| API rate limiting / HTTPS production / secret management | Deployment configuration | Operational hardening required |
