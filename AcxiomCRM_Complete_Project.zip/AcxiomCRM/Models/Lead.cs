using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class Lead
{
    public int LeadId { get; set; }
    [StringLength(100)] public string LeadCode { get; set; } = "";
    [Required, StringLength(120)] public string LeadName { get; set; } = "";
    [Required, EmailAddress, StringLength(160)] public string Email { get; set; } = "";
    [Required, RegularExpression(@"^\+?[0-9\s\-()]{10,16}$")] public string Phone { get; set; } = "";
    [StringLength(120)] public string? CompanyName { get; set; }
    [Required] public string Source { get; set; } = "Website";
    [Required] public string Status { get; set; } = "New";
    [Required] public string Priority { get; set; } = "Normal";
    [Range(0, 1000000000)] public decimal ExpectedValue { get; set; }
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public string? AssignedTo { get; set; }
    public string? Notes { get; set; }
}
