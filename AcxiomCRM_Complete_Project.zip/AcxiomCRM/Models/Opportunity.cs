using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class Opportunity
{
    public int OpportunityId { get; set; }
    [Required, StringLength(140)] public string OpportunityName { get; set; } = "";
    public int? CustomerId { get; set; }
    public int? LeadId { get; set; }
    [Range(0.01, 1000000000, ErrorMessage="Opportunity Amount must be greater than 0.")] public decimal Amount { get; set; }
    [Required] public string Stage { get; set; } = "Qualification";
    [Range(0,100,ErrorMessage="Probability must be between 0 and 100.")] public int Probability { get; set; } = 10;
    [DataType(DataType.Date)] public DateTime ExpectedCloseDate { get; set; } = DateTime.Today.AddDays(30);
    [Required] public string Status { get; set; } = "Open";
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public string? AssignedTo { get; set; }
    public string? Notes { get; set; }
    public decimal WeightedValue => Amount * Probability / 100m;
}
